import static org.junit.Assert.*;

import org.junit.Test;

/**
 * 
 */

/**
 * @author Da'Von
 *
 */
public class ObservationTests
{

    /**
     * 
     */
    @Test
    public void testIsValid()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testObservation()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetValue()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetStid()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testToString()
    {
        fail("Not yet implemented");
    }
    
}
