import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author Da'Von
 *
 */
public class StatisticsTests
{

    /**
     * 
     */
    @Test
    public void testStatisticsDoubleStringStringIntStatsType()
    {
        fail("Not yet implemented");
    }

    /**
     *
     */
    @Test
    public void testStatisticsDoubleStringGregorianCalendarIntStatsType()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testCreateDateFromString()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testCreateStringFromDate()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetNumberOfReportingStations()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetUTCDateTimeString()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testNewerThan()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testOlderThan()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testSameAs()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testToString()
    {
        fail("Not yet implemented");
    }

}
