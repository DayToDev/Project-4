import static org.junit.Assert.*;

import org.junit.Test;

/**
 * 
 */

/**
 * @author Da'Von
 *
 */
public class MapDataTests
{

    /**
     * 
     */
    @Test
    public void testMapData()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testCreateFileName()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testParseFile()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetTairMin()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetTairMax()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetTairAverage()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetTa9mMin()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetTa9mMax()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetTa9mAverage()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetSradMin()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetSradMax()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetSradAverage()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testGetSradTotal()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testToString()
    {
        fail("Not yet implemented");
    }

}
