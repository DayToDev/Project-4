import static org.junit.Assert.*;

import org.junit.Test;

/**
 * 
 */

/**
 * @author Da'Von
 *
 */
public class AbstractObservationTests
{

    /**
     * 
     */
    @Test
    public void testAbstractObservation()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testIsValid()
    {
        fail("Not yet implemented");
    }

}
