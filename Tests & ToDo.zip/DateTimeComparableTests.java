import static org.junit.Assert.*;

import org.junit.Test;

/**
 * 
 */

/**
 * @author Da'Von
 *
 */
public class DateTimeComparableTests
{

    /**
     * 
     */
    @Test
    public void testNewerThan()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testOlderThan()
    {
        fail("Not yet implemented");
    }

    /**
     * 
     */
    @Test
    public void testSameAs()
    {
        fail("Not yet implemented");
    }

}
